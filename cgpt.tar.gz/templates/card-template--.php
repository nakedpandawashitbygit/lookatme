<?php echo '<div>Template Loaded Successfully</div>'; ?>
